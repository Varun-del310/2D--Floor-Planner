package util;

import model.Door;
import model.FloorObject;
import model.Room;
import model.Wall;
import model.Window;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * FileManager handles saving and loading the floor plan to/from a plain
 * text file, using only core Java (BufferedReader/BufferedWriter).
 *
 * FILE FORMAT
 * -----------
 * Each floor object is stored on its own line as:
 *     TYPE,x,y,width,height
 * For example:
 *     ROOM,40,60,200,150
 *     WALL,40,60,200,10
 *     DOOR,120,60,30,10
 *     WINDOW,300,60,40,10
 *
 * This is a simple, human-readable format that is easy to explain in an
 * interview and easy to debug by just opening the file in a text editor.
 *
 * This class only has static methods and a private constructor because it
 * does not need to hold any state - it is a pure "helper" class.
 */
public class FileManager {

    private FileManager() {
        // Prevents instantiation - this class is used only through its
        // static methods, e.g. FileManager.save(...) / FileManager.load(...)
    }

    /**
     * Writes every FloorObject in the given list to the given file, one
     * object per line.
     */
    public static void save(ArrayList<FloorObject> objects, File file) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (FloorObject obj : objects) {
                writer.write(obj.toSaveLine());
                writer.newLine();
            }
        }
        // The try-with-resources block above automatically closes the
        // writer for us, even if an exception happens while writing.
    }

    /**
     * Reads the given file line by line and recreates the list of
     * FloorObjects that were saved there.
     */
    public static ArrayList<FloorObject> load(File file) throws IOException {
        ArrayList<FloorObject> objects = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue; // skip blank lines
                }

                String[] parts = line.split(",");
                if (parts.length != 5) {
                    continue; // skip malformed lines instead of crashing
                }

                String type = parts[0];
                int x = Integer.parseInt(parts[1]);
                int y = Integer.parseInt(parts[2]);
                int width = Integer.parseInt(parts[3]);
                int height = Integer.parseInt(parts[4]);

                FloorObject obj = createObject(type, x, y, width, height);
                if (obj != null) {
                    objects.add(obj);
                }
            }
        }

        return objects;
    }

    /**
     * Creates the correct subclass of FloorObject based on the type name
     * that was stored in the file. This is the "reverse" of getTypeName().
     */
    private static FloorObject createObject(String type, int x, int y, int width, int height) {
        switch (type) {
            case "ROOM":
                return new Room(x, y, width, height);
            case "WALL":
                return new Wall(x, y, width, height);
            case "DOOR":
                return new Door(x, y, width, height);
            case "WINDOW":
                return new Window(x, y, width, height);
            default:
                return null; // unknown type - safely ignore it
        }
    }
}

package util;

import java.awt.Color;

/**
 * ProjectConstants holds shared, unchanging values used across the
 * application (canvas size, grid appearance, default file name, etc).
 *
 * Keeping these values in one place means if we ever want to, say, change
 * the canvas size or grid spacing, we only need to change it here instead
 * of hunting through every class.
 *
 * The constructor is private because this class is never meant to be
 * instantiated - it only exists to hold "public static final" constants.
 */
public class ProjectConstants {

    public static final int CANVAS_WIDTH = 900;
    public static final int CANVAS_HEIGHT = 600;

    public static final int GRID_SIZE = 20;
    public static final Color GRID_COLOR = new Color(230, 230, 230);

    public static final String DEFAULT_SAVE_FILE_NAME = "floorplan.txt";

    // Prevents anyone from writing "new ProjectConstants()" by accident.
    private ProjectConstants() {
    }
}

package ui;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;

/**
 * MainFrame is the top-level application window. It is responsible for
 * arranging the three main pieces of the UI:
 *   - ToolbarPanel   (top)
 *   - DrawingPanel   (center - the canvas)
 *   - statusBar      (bottom - a simple JLabel)
 *
 * MainFrame does not contain any drawing or business logic itself - it
 * simply builds the window and wires the other pieces together. This is
 * an example of COMPOSITION: a MainFrame "has a" ToolbarPanel and "has a"
 * DrawingPanel, rather than being one giant class that does everything.
 */
public class MainFrame extends JFrame {

    private final DrawingPanel drawingPanel;
    private final ToolbarPanel toolbarPanel;
    private final JLabel statusBar;

    public MainFrame() {
        super("2D Floor Planner");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // The DrawingPanel needs a reference back to this MainFrame so it
        // can update the status bar text when things change.
        drawingPanel = new DrawingPanel(this);
        toolbarPanel = new ToolbarPanel(drawingPanel, this);

        statusBar = new JLabel("Tool: SELECT  |  Objects: 0");
        statusBar.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        add(toolbarPanel, BorderLayout.NORTH);
        add(drawingPanel, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);

        // pack() resizes the window to fit the preferred sizes of its
        // contents (mainly the DrawingPanel's preferred canvas size).
        pack();
        setLocationRelativeTo(null); // center the window on the screen
    }

    /** Lets other classes (DrawingPanel, ToolbarPanel) update the status bar. */
    public void setStatusText(String text) {
        statusBar.setText(text);
    }
}

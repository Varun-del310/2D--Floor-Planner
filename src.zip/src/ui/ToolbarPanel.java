package ui;

import model.FloorObject;
import model.ToolType;
import util.FileManager;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * ToolbarPanel is the row of buttons across the top of the window: Room,
 * Wall, Door, Window, Select, Delete, Save, Load, Clear.
 *
 * This class holds a reference to the DrawingPanel (COMPOSITION - a
 * ToolbarPanel "has a" DrawingPanel it talks to) so that clicking a
 * button can directly tell the canvas what to do, e.g. "switch to Wall
 * tool" or "delete the selected object".
 *
 * We keep this simple by having each button's ActionListener directly
 * call a method on DrawingPanel or FileManager, instead of building a more
 * complex event system - that keeps things easy to follow for a beginner.
 */
public class ToolbarPanel extends JPanel {

    private final DrawingPanel drawingPanel;
    private final MainFrame mainFrame;

    public ToolbarPanel(DrawingPanel drawingPanel, MainFrame mainFrame) {
        this.drawingPanel = drawingPanel;
        this.mainFrame = mainFrame;

        setLayout(new FlowLayout(FlowLayout.LEFT));

        // Drawing tool buttons - each one just switches the active tool.
        addToolButton("Room", ToolType.ROOM);
        addToolButton("Wall", ToolType.WALL);
        addToolButton("Door", ToolType.DOOR);
        addToolButton("Window", ToolType.WINDOW);
        addToolButton("Select", ToolType.SELECT);

        // Action buttons - each one performs an immediate action.
        addActionButton("Delete", e -> drawingPanel.deleteSelected());
        addActionButton("Save", e -> handleSave());
        addActionButton("Load", e -> handleLoad());
        addActionButton("Clear", e -> handleClear());
    }

    /** Adds a button that switches the DrawingPanel to the given tool. */
    private void addToolButton(String label, ToolType tool) {
        JButton button = new JButton(label);
        button.addActionListener(e -> drawingPanel.setCurrentTool(tool));
        add(button);
    }

    /** Adds a button with a custom action, using a lambda for brevity. */
    private void addActionButton(String label, ActionListener listener) {
        JButton button = new JButton(label);
        button.addActionListener(listener);
        add(button);
    }

    /** Opens a "Save As" dialog and writes the current floor plan to disk. */
    private void handleSave() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("floorplan.txt"));

        int result = chooser.showSaveDialog(mainFrame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                FileManager.save(drawingPanel.getObjects(), file);
                mainFrame.setStatusText("Saved to " + file.getName());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(mainFrame,
                        "Could not save file: " + ex.getMessage(),
                        "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /** Opens an "Open" dialog and loads a floor plan from disk. */
    private void handleLoad() { 
        JFileChooser chooser = new JFileChooser();

        int result = chooser.showOpenDialog(mainFrame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                ArrayList<FloorObject> loadedObjects = FileManager.load(file);
                drawingPanel.setObjects(loadedObjects);
                mainFrame.setStatusText("Loaded " + file.getName());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(mainFrame,
                        "Could not load file: " + ex.getMessage(),
                        "Load Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /** Asks for confirmation, then clears the entire floor plan. */
    private void handleClear() {
        int confirm = JOptionPane.showConfirmDialog(
                mainFrame,
                "This will remove every object from the floor plan. Continue?",
                "Confirm Clear",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            drawingPanel.clearAll();
        }
    }
}

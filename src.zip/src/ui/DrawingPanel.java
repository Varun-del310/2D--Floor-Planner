package ui;

import model.Door;
import model.FloorObject;
import model.Room;
import model.ToolType;
import model.Wall;
import model.Window;
import util.ProjectConstants;

import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

/**
 * DrawingPanel is the canvas in the middle of the window where the user
 * actually draws and edits the floor plan.
 *
 * This class is the most important one in the project. It is responsible
 * for:
 *   - keeping the list of all FloorObjects currently on the plan
 *   - repainting them every time something changes (paintComponent)
 *   - listening for mouse clicks/drags to draw, select, move, and resize
 *     objects
 *   - listening for the Delete key to remove the selected object
 *
 * It implements MouseListener, MouseMotionListener, and KeyListener
 * directly (instead of using separate listener classes) to keep the
 * project simple - all the interaction code lives in one place.
 */
public class DrawingPanel extends JPanel implements MouseListener, MouseMotionListener, KeyListener {

    // All the shapes currently on the floor plan.
    private ArrayList<FloorObject> objects = new ArrayList<>();

    // Which tool is currently active (ROOM, WALL, DOOR, WINDOW, or SELECT).
    private ToolType currentTool = ToolType.SELECT;

    // The object the user currently has selected, or null if nothing is selected.
    private FloorObject selectedObject = null;

    // Reference back to the main window so we can update the status bar text.
    private MainFrame mainFrame;

    /**
     * Mode describes what the mouse is currently "doing". We use this to
     * decide what mouseDragged() and mouseReleased() should do next.
     */
    private enum Mode {
        NONE,        // mouse is not currently doing anything special
        DRAWING_NEW, // user is dragging out a brand-new shape
        MOVING,      // user is dragging an existing selected shape
        RESIZING     // user is dragging the resize handle of a selected shape
    }

    private Mode mode = Mode.NONE;

    // Used while drawing a brand-new shape: where the drag started and
    // where the mouse currently is, so we can show a live preview rectangle.
    private Point dragStart;
    private Point dragCurrent;

    // When moving an object, this is the offset between where the user
    // clicked and the object's top-left corner, so the object doesn't
    // "jump" to have its corner under the mouse the moment you start dragging.
    private int moveOffsetX;
    private int moveOffsetY;

    public DrawingPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(ProjectConstants.CANVAS_WIDTH, ProjectConstants.CANVAS_HEIGHT));

        addMouseListener(this);
        addMouseMotionListener(this);

        // A JPanel does not receive keyboard events unless it is
        // "focusable" and actually has focus, so we enable that here.
        setFocusable(true);
        addKeyListener(this);
    }

    /** Called by the toolbar whenever the user picks a different tool. */
    public void setCurrentTool(ToolType tool) {
        this.currentTool = tool;
        if (tool != ToolType.SELECT) {
            // Switching to a drawing tool clears the current selection,
            // since Select mode is the only mode that supports selection.
            deselectAll();
            repaint();
        }
        updateStatusBar();
    }

    /** Removes the currently selected object, if any. Used by the Delete
     *  toolbar button and the Delete/Backspace keyboard keys. */
    public void deleteSelected() {
        if (selectedObject != null) {
            objects.remove(selectedObject);
            selectedObject = null;
            repaint();
            updateStatusBar();
        }
    }

    /** Removes every object from the floor plan. Used by the Clear button. */
    public void clearAll() {
        objects.clear();
        selectedObject = null;
        repaint();
        updateStatusBar();
    }

    /** Returns the live list of objects, e.g. so FileManager can save them. */
    public ArrayList<FloorObject> getObjects() {
        return objects;
    }

    /** Replaces the current list of objects, e.g. after loading a file. */
    public void setObjects(ArrayList<FloorObject> newObjects) {
        this.objects = newObjects;
        this.selectedObject = null;
        repaint();
        updateStatusBar();
    }

    private void deselectAll() {
        for (FloorObject obj : objects) {
            obj.setSelected(false);
        }
        selectedObject = null;
    }

    /** Pushes a helpful summary of the current state to the status bar. */
    private void updateStatusBar() {
        if (mainFrame == null) {
            return;
        }
        StringBuilder text = new StringBuilder();
        text.append("Tool: ").append(currentTool);
        text.append("  |  Objects: ").append(objects.size());
        if (selectedObject != null) {
            text.append("  |  Selected: ").append(selectedObject.getTypeName());
        }
        mainFrame.setStatusText(text.toString());
    }

    // -----------------------------------------------------------------
    // PAINTING
    // -----------------------------------------------------------------

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawGrid(g2d);

        // POLYMORPHISM IN ACTION: we don't know (or care) whether each
        // "obj" is really a Room, Wall, Door, or Window - we just call
        // draw() and Java runs the correct version for us.
        for (FloorObject obj : objects) {
            obj.draw(g2d);
        }

        // While the user is dragging out a brand-new shape, show a
        // dashed preview rectangle so they can see what they're about to create.
        if (mode == Mode.DRAWING_NEW && dragStart != null && dragCurrent != null) {
            drawPreviewRectangle(g2d);
        }
    }

    /** Draws a faint background grid to help the user line things up. */
    private void drawGrid(Graphics2D g2d) {
        g2d.setColor(ProjectConstants.GRID_COLOR);
        for (int gx = 0; gx < getWidth(); gx += ProjectConstants.GRID_SIZE) {
            g2d.drawLine(gx, 0, gx, getHeight());
        }
        for (int gy = 0; gy < getHeight(); gy += ProjectConstants.GRID_SIZE) {
            g2d.drawLine(0, gy, getWidth(), gy);
        }
    }

    private void drawPreviewRectangle(Graphics2D g2d) {
        Rectangle r = rectangleFromPoints(dragStart, dragCurrent);
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, new float[]{4}, 0));
        g2d.drawRect(r.x, r.y, r.width, r.height);
        // Reset to a plain solid stroke so it doesn't leak into other drawing.
        g2d.setStroke(new BasicStroke(1));
    }

    /**
     * Given two arbitrary points (the drag start and drag end), returns the
     * normalized rectangle between them. This is needed because the user
     * might drag up-and-left just as easily as down-and-right, and a
     * Rectangle must always have a non-negative width/height.
     */
    private Rectangle rectangleFromPoints(Point a, Point b) {
        int x = Math.min(a.x, b.x);
        int y = Math.min(a.y, b.y);
        int w = Math.abs(a.x - b.x);
        int h = Math.abs(a.y - b.y);
        return new Rectangle(x, y, w, h);
    }

    // -----------------------------------------------------------------
    // MOUSE EVENTS
    // -----------------------------------------------------------------

    @Override
    public void mousePressed(MouseEvent e) {
        // Clicking the canvas should give it keyboard focus, so the
        // Delete key works right away without needing an extra click.
        requestFocusInWindow();

        Point p = e.getPoint();

        if (currentTool == ToolType.SELECT) {
            // If something is already selected and the user clicked its
            // resize handle, start resizing instead of re-selecting.
            if (selectedObject != null && selectedObject.isOnResizeHandle(p.x, p.y)) {
                mode = Mode.RESIZING;
                return;
            }

            FloorObject clicked = findTopObjectAt(p.x, p.y);
            deselectAll();

            if (clicked != null) {
                clicked.setSelected(true);
                selectedObject = clicked;
                moveOffsetX = p.x - clicked.getX();
                moveOffsetY = p.y - clicked.getY();
                mode = Mode.MOVING;
            } else {
                mode = Mode.NONE;
            }

            repaint();
            updateStatusBar();

        } else {
            // Any tool other than SELECT means the user is starting to
            // draw a brand-new shape.
            dragStart = p;
            dragCurrent = p;
            mode = Mode.DRAWING_NEW;
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Point p = e.getPoint();

        switch (mode) {
            case DRAWING_NEW:
                dragCurrent = p;
                repaint();
                break;

            case MOVING:
                if (selectedObject != null) {
                    selectedObject.moveTo(p.x - moveOffsetX, p.y - moveOffsetY);
                    repaint();
                }
                break;

            case RESIZING:
                if (selectedObject != null) {
                    int newWidth = p.x - selectedObject.getX();
                    int newHeight = p.y - selectedObject.getY();
                    selectedObject.resizeTo(newWidth, newHeight);
                    repaint();
                }
                break;

            case NONE:
            default:
                // Nothing to do.
                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (mode == Mode.DRAWING_NEW && dragStart != null && dragCurrent != null) {
            Rectangle r = rectangleFromPoints(dragStart, dragCurrent);

            // Ignore accidental tiny clicks/drags so we don't create
            // invisible 1x1 pixel shapes.
            if (r.width > 5 && r.height > 5) {
                FloorObject newObject = createObjectForTool(currentTool, r.x, r.y, r.width, r.height);
                if (newObject != null) {
                    objects.add(newObject);
                }
            }

            dragStart = null;
            dragCurrent = null;
        }

        mode = Mode.NONE;
        repaint();
        updateStatusBar();
    }

    /**
     * Creates a new FloorObject of the correct subclass based on which
     * drawing tool is currently active. This is where a ToolType (an enum
     * value) gets turned into an actual object in memory.
     */
    private FloorObject createObjectForTool(ToolType tool, int x, int y, int width, int height) {
        switch (tool) {
            case ROOM:
                return new Room(x, y, width, height);
            case WALL:
                return new Wall(x, y, width, height);
            case DOOR:
                return new Door(x, y, width, height);
            case WINDOW:
                return new Window(x, y, width, height);
            default:
                return null;
        }
    }

    /**
     * Finds the top-most object under the given point, or null if there
     * isn't one. We search from the end of the list backwards so that if
     * two shapes overlap, the one drawn most recently (visually on top)
     * is the one that gets selected.
     */
    private FloorObject findTopObjectAt(int x, int y) {
        for (int i = objects.size() - 1; i >= 0; i--) {
            if (objects.get(i).contains(x, y)) {
                return objects.get(i);
            }
        }
        return null;
    }

    // These methods are part of the MouseListener/MouseMotionListener
    // interfaces but we don't need them - Java requires we still provide
    // an (empty) implementation for every method in the interface.
    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    // -----------------------------------------------------------------
    // KEYBOARD EVENTS
    // -----------------------------------------------------------------

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            deleteSelected();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}

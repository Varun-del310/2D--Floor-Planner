package app;

import ui.MainFrame;

import javax.swing.SwingUtilities;

/**
 * Main is the entry point of the application - the class Java runs first
 * when you start the program.
 *
 * Its only job is to create the MainFrame and make it visible. We do this
 * inside SwingUtilities.invokeLater(...) because Swing components should
 * always be created and updated on a special thread called the
 * "Event Dispatch Thread" (EDT), not on the default "main" thread. This is
 * a standard best-practice for any Swing application.
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}

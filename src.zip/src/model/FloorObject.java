package model;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Stroke;

/**
 * FloorObject is the parent class for every shape that can appear on the
 * drawing canvas (Room, Wall, Door, Window).
 *
 * WHY THIS CLASS EXISTS
 * ----------------------
 * Instead of writing separate, unrelated code for a room rectangle, a wall
 * rectangle, a door rectangle, etc., we notice that they all share the same
 * basic behaviour:
 *   - they live at some (x, y) position
 *   - they have a width and height
 *   - they can be selected, moved, and resized
 *   - they need to know if the mouse clicked inside them
 *
 * By putting all of that shared behaviour here, each subclass only needs to
 * add the one thing that makes it different: how it actually looks when
 * painted on screen. This is a classic example of INHERITANCE
 * (subclasses reuse this code) and POLYMORPHISM (DrawingPanel can treat
 * every object in its list as a "FloorObject" and call draw() on it,
 * without caring whether it is really a Room, Wall, Door, or Window).
 *
 * This class is declared "abstract" because it does not make sense to draw
 * a generic, type-less FloorObject on the screen - you can only ever create
 * a concrete Room, Wall, Door, or Window.
 */
public abstract class FloorObject {

    // Position (top-left corner) and size of the shape, in pixels on the canvas.
    // These are "protected" (not private) so subclasses can read/adjust them
    // directly if they ever need to - this is ENCAPSULATION with a
    // slightly relaxed visibility for the benefit of subclasses.
    protected int x;
    protected int y;
    protected int width;
    protected int height;

    // Whether the user has currently selected this object with a click.
    protected boolean selected;

    // The size (in pixels) of the little square handle drawn in the
    // bottom-right corner of a selected object, used for resizing.
    public static final int HANDLE_SIZE = 8;

    // We never allow an object to be resized smaller than this, so the
    // user cannot accidentally shrink something down to nothing.
    private static final int MIN_SIZE = 10;

    /**
     * Constructor - every FloorObject needs an initial position and size.
     * Subclasses simply call this via super(x, y, width, height).
     */
    public FloorObject(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.selected = false;
    }

    /**
     * Draws this object onto the given Graphics2D context.
     * Each subclass (Room, Wall, Door, Window) OVERRIDES this method to
     * draw itself with its own color and style. This is METHOD OVERRIDING
     * and is the main example of POLYMORPHISM in this project: the
     * DrawingPanel just calls object.draw(g2d) for every object in its
     * list, and Java automatically runs the correct subclass version.
     */
    public abstract void draw(Graphics2D g2d);

    /**
     * Returns a short, unique name for this type of object (e.g. "ROOM").
     * This is used when saving/loading files, so we know which subclass
     * to recreate when we read a line back from disk.
     */
    public abstract String getTypeName();

    /** Returns true if the given canvas point (px, py) is inside this shape. */
    public boolean contains(int px, int py) {
        return getBounds().contains(px, py);
    }

    /** Convenience method that returns this object's bounding rectangle. */
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    /**
     * Returns the small square area (bottom-right corner) that the user can
     * click-and-drag to resize this object.
     */
    public Rectangle getResizeHandleBounds() {
        return new Rectangle(
                x + width - HANDLE_SIZE / 2,
                y + height - HANDLE_SIZE / 2,
                HANDLE_SIZE,
                HANDLE_SIZE);
    }

    /** Returns true if the given point is on top of the resize handle. */
    public boolean isOnResizeHandle(int px, int py) {
        return getResizeHandleBounds().contains(px, py);
    }

    /** Moves this object so its top-left corner is at (newX, newY). */
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
    }

    /**
     * Resizes this object to the given width/height, never allowing it to
     * go below MIN_SIZE so the shape can't disappear.
     */
    public void resizeTo(int newWidth, int newHeight) {
        this.width = Math.max(newWidth, MIN_SIZE);
        this.height = Math.max(newHeight, MIN_SIZE);
    }

    /**
     * Draws a red selection border and the resize handle if this object is
     * currently selected. Every subclass calls this at the end of its own
     * draw() method, so selection always looks the same no matter what
     * kind of shape is selected.
     */
    protected void drawSelectionHighlight(Graphics2D g2d) {
        if (!selected) {
            return;
        }
        // Remember the previous drawing settings so we can restore them -
        // otherwise every shape drawn AFTER this one would also turn red!
        Color previousColor = g2d.getColor();
        Stroke previousStroke = g2d.getStroke();

        g2d.setColor(Color.RED);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRect(x, y, width, height);

        // Draw a small filled square as the resize handle.
        g2d.fillRect(
                x + width - HANDLE_SIZE / 2,
                y + height - HANDLE_SIZE / 2,
                HANDLE_SIZE,
                HANDLE_SIZE);

        g2d.setColor(previousColor);
        g2d.setStroke(previousStroke);
    }

    // ---------------------------------------------------------------
    // Simple getters and setters (ENCAPSULATION: fields stay protected,
    // outside classes must go through these methods to read/change them).
    // ---------------------------------------------------------------

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * Converts this object into one line of text for saving to a file.
     * Format: TYPE,x,y,width,height
     * Example: ROOM,40,60,200,150
     */
    public String toSaveLine() {
        return getTypeName() + "," + x + "," + y + "," + width + "," + height;
    }
}

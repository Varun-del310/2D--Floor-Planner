package model;

/**
 * ToolType lists every drawing/interaction mode the user can pick from the
 * toolbar. The DrawingPanel checks the current ToolType to decide what to
 * do when the mouse is pressed and dragged.
 *
 * Using an enum here (instead of, say, plain Strings or numbers) means the
 * compiler protects us from typos like "ROOOM" - only the values listed
 * below are valid.
 */
public enum ToolType {
    ROOM,
    WALL,
    DOOR,
    WINDOW,
    SELECT
}

package model;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Wall represents a solid black wall segment.
 * It is drawn as a completely filled black rectangle - usually the user
 * will draw walls as thin, long rectangles (e.g. drag a long, short shape).
 *
 * Like Room, this class extends FloorObject and only overrides the parts
 * that make a Wall look different from other shapes.
 */
public class Wall extends FloorObject {

    public Wall(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.BLACK);
        g2d.fillRect(x, y, width, height);

        drawSelectionHighlight(g2d);
    }

    @Override
    public String getTypeName() {
        return "WALL";
    }
}

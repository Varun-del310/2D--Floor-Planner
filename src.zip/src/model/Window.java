package model;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Window represents a window opening in a wall.
 * It is drawn as a cyan rectangle with two black lines across it,
 * suggesting window panes.
 *
 * NOTE: This class is named "Window", same as java.awt.Window. That is
 * fine because this class lives in its own "model" package and none of
 * our files import java.awt.Window, so there is no naming conflict.
 */
public class Window extends FloorObject {

    public Window(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.CYAN);
        g2d.fillRect(x, y, width, height);

        // Draw two black lines to look like window panes.
        g2d.setColor(Color.BLACK);
        g2d.drawRect(x, y, width, height);
        if (width >= height) {
            int midX = x + width / 2;
            g2d.drawLine(midX, y, midX, y + height);
        } else {
            int midY = y + height / 2;
            g2d.drawLine(x, midY, x + width, midY);
        }

        drawSelectionHighlight(g2d);
    }

    @Override
    public String getTypeName() {
        return "WINDOW";
    }
}

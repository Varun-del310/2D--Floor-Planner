package model;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Door represents a door opening in a wall.
 * It is drawn as a blue rectangle with a white line through the middle,
 * which gives it a simple "door panel" look without needing complicated
 * arc/hinge geometry.
 */
public class Door extends FloorObject {

    public Door(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.BLUE);
        g2d.fillRect(x, y, width, height);

        // Draw a simple white line down the middle to suggest a door panel.
        g2d.setColor(Color.WHITE);
        if (width >= height) {
            // Wide door: draw a vertical line in the middle.
            int midX = x + width / 2;
            g2d.drawLine(midX, y, midX, y + height);
        } else {
            // Tall door: draw a horizontal line in the middle.
            int midY = y + height / 2;
            g2d.drawLine(x, midY, x + width, midY);
        }

        drawSelectionHighlight(g2d);
    }

    @Override
    public String getTypeName() {
        return "DOOR";
    }
}

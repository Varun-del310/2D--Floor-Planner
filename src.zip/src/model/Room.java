package model;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Room represents a rectangular room in the floor plan.
 * It is drawn as a light gray filled rectangle with a dark gray border.
 *
 * This class demonstrates INHERITANCE: it extends FloorObject and reuses
 * all of the positioning, selection, and resizing logic already written
 * there. The only thing Room adds is its own appearance.
 */
public class Room extends FloorObject {

    /**
     * Constructor simply passes the position/size up to FloorObject's
     * constructor using super(...). This is COMPOSITION-friendly design:
     * Room does not need to repeat any of that logic itself.
     */
    public Room(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    /**
     * Draws a room as a light gray rectangle with a darker outline.
     * This OVERRIDES the abstract draw() method from FloorObject.
     */
    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(x, y, width, height);

        g2d.setColor(Color.DARK_GRAY);
        g2d.drawRect(x, y, width, height);

        // Always draw the selection highlight last, so it appears on top.
        drawSelectionHighlight(g2d);
    }

    @Override
    public String getTypeName() {
        return "ROOM";
    }
}
